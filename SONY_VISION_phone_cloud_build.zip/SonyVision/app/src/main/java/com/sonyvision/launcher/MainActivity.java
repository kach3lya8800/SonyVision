package com.sonyvision.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(9,13,22);
    private final int panel = Color.rgb(23,31,46);
    private final int accent = Color.rgb(120,169,255);
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUi();
    }

    private void buildUi() {
        ScrollView page = new ScrollView(this);
        page.setFillViewport(true);
        page.setBackgroundColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(48), dp(28), dp(48), dp(32));
        page.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("SONY VISION", 25, Color.WHITE, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView date = text(new SimpleDateFormat("EEEE, d MMMM   •   HH:mm", new Locale("ru")).format(new Date()), 16, 0xFFB8C3D6, false);
        top.addView(date);
        root.addView(top);

        TextView greeting = text("Добро пожаловать домой", 34, Color.WHITE, true);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2); gp.topMargin = dp(42); root.addView(greeting, gp);
        TextView subtitle = text("Ваши развлечения. На одном экране.", 17, 0xFF9BA9BF, false);
        root.addView(subtitle);

        TextView featured = text("Продолжить просмотр", 21, Color.WHITE, true);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1,-2); fp.topMargin=dp(34); root.addView(featured,fp);
        TextView hero = text("Откройте любимые приложения\nи выберите, что посмотреть сегодня", 20, Color.WHITE, true);
        hero.setGravity(Gravity.CENTER_VERTICAL); hero.setPadding(dp(28),0,dp(28),0);
        hero.setBackground(round(0xFF203B63, 22));
        hero.setFocusable(true); hero.setFocusableInTouchMode(true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(150)); hp.topMargin=dp(14); root.addView(hero,hp);
        hero.setOnClickListener(v -> showApps());
        focusStyle(hero);

        TextView appsTitle = text("Приложения", 22, Color.WHITE, true);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1,-2); ap.topMargin=dp(32); root.addView(appsTitle,ap);
        HorizontalScrollView strip = new HorizontalScrollView(this); strip.setHorizontalScrollBarEnabled(false);
        LinearLayout tiles = new LinearLayout(this); tiles.setOrientation(LinearLayout.HORIZONTAL);
        strip.addView(tiles); root.addView(strip);
        addShortcut(tiles,"Все приложения","Открыть список",()->showApps());
        addShortcut(tiles,"Настройки","Настройки телевизора",()->openSettings());
        addShortcut(tiles,"Источники","HDMI и входы",()->openInputs());

        TextView note = text("SONY VISION • Концепт 0.1", 13, 0xFF718096, false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin=dp(28); root.addView(note,np);
        setContentView(page);
        if (hero != null) hero.requestFocus();
    }

    private void addShortcut(LinearLayout parent, String title, String desc, Runnable action) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18),dp(12),dp(18),dp(12)); card.setBackground(round(panel,18)); card.setFocusable(true); card.setFocusableInTouchMode(true);
        TextView t=text(title,18,Color.WHITE,true); TextView d=text(desc,13,0xFF9BA9BF,false);
        card.addView(t); LinearLayout.LayoutParams dp2=new LinearLayout.LayoutParams(-1,-2); dp2.topMargin=dp(6); card.addView(d,dp2);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(220),dp(112)); cp.rightMargin=dp(14); cp.topMargin=dp(14); parent.addView(card,cp);
        card.setOnClickListener(v->action.run()); focusStyle(card);
    }

    private void showApps() {
        PackageManager pm=getPackageManager();
        Intent query=new Intent(Intent.ACTION_MAIN); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ApplicationInfo> apps=new ArrayList<>(pm.getInstalledApplications(0));
        Collections.sort(apps,(a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(22),dp(12),dp(22),dp(12));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Приложения").setView(list).setNegativeButton("Закрыть",null).create();
        int count=0;
        for(ApplicationInfo app:apps){
            Intent launch=pm.getLaunchIntentForPackage(app.packageName);
            if(launch==null) continue;
            TextView item=text("▸  "+pm.getApplicationLabel(app).toString(),18,Color.WHITE,false);
            item.setPadding(dp(12),dp(13),dp(12),dp(13)); item.setFocusable(true); item.setBackground(round(panel,12));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(7); list.addView(item,lp);
            item.setOnClickListener(v->{try{startActivity(launch);}catch(Exception ignored){}}); focusStyle(item); count++;
        }
        if(count==0) list.addView(text("Не удалось найти приложения с ярлыками.",16,Color.WHITE,false));
        dialog.show();
    }

    private void openSettings(){ try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){}}
    private void openInputs(){
        Intent i=new Intent("com.sony.dtv.intent.action.HOME");
        try{startActivity(i);}catch(Exception e){new AlertDialog.Builder(this).setMessage("Откройте меню входов кнопкой INPUT на пульте телевизора.").setPositiveButton("Понятно",null).show();}
    }
    private TextView text(String s,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private void focusStyle(View v){v.setOnFocusChangeListener((view,focused)->{view.setScaleX(focused?1.035f:1f);view.setScaleY(focused?1.035f:1f);view.setBackground(round(focused?0xFF304C76:panel,18));});}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
